package com.Ecar;


import com.Ecar.Entities.ClienteDAO;
import com.Ecar.Repositories.ClienteRepository;
import com.Ecar.View.ClienteView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class EcarApplication implements CommandLineRunner {
	@Autowired
	ClienteRepository clienteRepository;


	public static void main(String[] args) {
		SpringApplication.run(EcarApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		ClienteDAO clienteDAO = new ClienteDAO();
		clienteDAO.setId(1);
		clienteDAO.setNome("Joao");
		clienteDAO.setCep("06867650");
		clienteDAO.setCpf("12345678991");
		clienteRepository.save(clienteDAO);
	}
}
