package com.Ecar.Repositories;

import com.Ecar.Entities.ClienteDAO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepository extends JpaRepository<ClienteDAO, Long> {

}
