package com.Ecar.View;

import com.Ecar.Controllers.ClienteController;
import com.Ecar.Entities.ClienteDAO;
import com.Ecar.Repositories.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;

import javax.swing.*;
import java.util.Scanner;

public class ClienteView {
    ClienteController clienteController;
    @Autowired
    private ClienteDAO clienteDAO;
    @Autowired
    private ClienteRepository clienteRepository;
    public ClienteView(){
    }
  public void registroCliente() {
      clienteDAO.setId(1);
      clienteDAO.setNome("Nome: ");
      clienteDAO.setCep("CEP: ");
      clienteDAO.setCpf("CPF: ");
      clienteRepository.save(clienteDAO);
  }

}
