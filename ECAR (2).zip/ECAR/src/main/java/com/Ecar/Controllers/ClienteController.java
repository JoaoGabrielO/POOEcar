package com.Ecar.Controllers;

import java.util.Optional;

import com.Ecar.Entities.ClienteDAO;
import com.Ecar.Repositories.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping(value = "/cliente")
public class ClienteController {

    @Autowired
    private ClienteRepository repository;
    @GetMapping
    public ResponseEntity<Object> findAll(){

        return ResponseEntity.status(HttpStatus.OK).body(repository.findAll());    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<Object> findById(@PathVariable long id){
        Optional<ClienteDAO> clienteDAOOptional = repository.findById(id);

        if(!clienteDAOOptional.isPresent()){
            ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cliente não encontrado.");
        }
        return ResponseEntity.status(HttpStatus.OK).body(clienteDAOOptional.get());    }


    @PostMapping(value = "/{id}")
    public ClienteDAO insert(@RequestBody ClienteDAO clienteDAO){
        ClienteDAO result = repository.save(clienteDAO);

        return result;
    }
}
