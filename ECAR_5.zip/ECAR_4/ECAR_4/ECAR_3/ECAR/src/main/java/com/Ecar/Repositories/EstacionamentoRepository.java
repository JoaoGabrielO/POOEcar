package com.Ecar.Repositories;

import com.Ecar.Entities.EstacionamentoDAO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstacionamentoRepository extends JpaRepository<EstacionamentoDAO, Long> {
}
