package com.Ecar.Controllers;

import com.Ecar.Entities.ClienteDAO;
import com.Ecar.Entities.EstacionamentoDAO;
import com.Ecar.Repositories.EstacionamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping(value = "/estacionamentos")
public class EstacionamentoController {

    @Autowired
    private EstacionamentoRepository repository;

    @GetMapping
    public ResponseEntity<Object> findAll() {

        return ResponseEntity.status(HttpStatus.OK).body(repository.findAll());
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<Object> findById(@PathVariable long id) {
        Optional<EstacionamentoDAO> estacionamentoDAOOptional = repository.findById(id);

        if (!estacionamentoDAOOptional.isPresent()) {
            ResponseEntity.status(HttpStatus.NOT_FOUND).body("Estacionamento não encontrado.");
        }
        return ResponseEntity.status(HttpStatus.OK).body(estacionamentoDAOOptional.get());
    }


    @PostMapping(value = "")
    public ResponseEntity<Object> insert(@RequestBody EstacionamentoDAO estacionamentoDAO) {
        if (validateCep(estacionamentoDAO.getCep())) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("O CEP invalido ou faltando caracteres!");
        }
        repository.save(estacionamentoDAO);
        return ResponseEntity.status(HttpStatus.CREATED).body("Estacionamento criado com sucesso.");
    }

    @PutMapping("/{id}")
    public ResponseEntity<EstacionamentoDAO> atualizarProduto(
            @PathVariable Long id,
            @RequestBody ClienteDAO produtoAtualizado) {
        Optional<EstacionamentoDAO> produtoOptional = repository.findById(id);
        if (produtoOptional.isPresent()) {
            EstacionamentoDAO estacionamentoDAO = produtoOptional.get();
            estacionamentoDAO.setNome(produtoAtualizado.getNome());
            if (validateCep(produtoAtualizado.getCep())) {
                estacionamentoDAO.setCep(produtoAtualizado.getCep());

            } else {
                ResponseEntity.status(HttpStatus.CONFLICT).body("O CEP invalido ou faltando caracteres!");
            }
            repository.save(estacionamentoDAO);

            return ResponseEntity.ok(estacionamentoDAO);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Object> remover ( @PathVariable long id){
        Optional<EstacionamentoDAO> estacionamentoDAOOptional = repository.findById(id);

        if (estacionamentoDAOOptional.isPresent()) {
            EstacionamentoDAO estacionamentoDAO = estacionamentoDAOOptional.get();
            repository.delete(estacionamentoDAO);
            return ResponseEntity.ok("Estacionamento removido com sucesso.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Estacionamento não encontrado");
        }
    }


    public static boolean validateCep (String cep){
        // Remover caracteres não numéricos
        String cepNumerico = cep.replaceAll("\\D", "");

        // Verificar se o CEP possui exatamente 8 dígitos
        if (cepNumerico.length() != 8) {
            return false;
        }

        // Verificar se o CEP é composto apenas por dígitos repetidos
        if (cepNumerico.matches("(\\d)\\1{7}")) {
            return false;
        }

        // Validar o CEP de acordo com regras específicas (se necessário)

        // Retornar true se o CEP for válido
        return true;
    }
}

