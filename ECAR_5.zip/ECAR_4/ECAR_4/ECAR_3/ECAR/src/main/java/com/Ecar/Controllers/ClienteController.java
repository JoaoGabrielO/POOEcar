package com.Ecar.Controllers;


import java.util.Optional;
import com.Ecar.Entities.ClienteDAO;
import com.Ecar.Repositories.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping(value = "/clientes")
public class ClienteController {

    @Autowired
    private ClienteRepository repository;

    @GetMapping
    public ResponseEntity<Object> findAll() {

        return ResponseEntity.status(HttpStatus.OK).body(repository.findAll());
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<Object> findById(@PathVariable long id) {
        Optional<ClienteDAO> clienteDAOOptional = repository.findById(id);

        if (!clienteDAOOptional.isPresent()) {
            ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cliente não encontrado.");
        }
        return ResponseEntity.status(HttpStatus.OK).body(clienteDAOOptional.get());
    }


    @PostMapping(value = "")
    public ResponseEntity<Object> insert(@RequestBody ClienteDAO clienteDAO) {
        if (validateCep(clienteDAO.getCep())) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("O CEP invalido ou faltando caracteres!");
        }
        if (validarCPF(clienteDAO.getCpf())) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("CPF invalido ou faltando caracteres!");
        }
        repository.save(clienteDAO);
        return ResponseEntity.status(HttpStatus.CREATED).body("Cliente criado com sucesso.");
    }

    @PutMapping("/{id}")
    public ResponseEntity<ClienteDAO> atualizarProduto(
            @PathVariable Long id,
            @RequestBody ClienteDAO produtoAtualizado) {
        Optional<ClienteDAO> produtoOptional = repository.findById(id);
        if (produtoOptional.isPresent()) {
            ClienteDAO clienteDAO = produtoOptional.get();
            clienteDAO.setNome(produtoAtualizado.getNome());
            if (validateCep(produtoAtualizado.getCep())) {
                clienteDAO.setCep(produtoAtualizado.getCep());

            } else {
                ResponseEntity.status(HttpStatus.CONFLICT).body("O CEP invalido ou faltando caracteres!");
            }
            if (validarCPF(produtoAtualizado.getCpf())) {
                clienteDAO.setCpf(produtoAtualizado.getCpf());

            } else {
                ResponseEntity.status(HttpStatus.CONFLICT).body("O CPF invalido ou faltando caracteres!");
            }
            repository.save(clienteDAO);

            return ResponseEntity.ok(clienteDAO);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
        @DeleteMapping(value = "/{id}")
        public ResponseEntity<Object> remover ( @PathVariable long id){
            Optional<ClienteDAO> clienteDAOOptional = repository.findById(id);

            if (clienteDAOOptional.isPresent()) {
                ClienteDAO clienteDAO = clienteDAOOptional.get();
                repository.delete(clienteDAO);
                return ResponseEntity.ok("Cliente removido com sucesso.");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cliente não encontrado");
            }
        }


        public static boolean validarCPF (String cpf){
            // Remover caracteres não numéricos
            String cpfNumerico = cpf.replaceAll("\\D", "");

            // Verificar se o CPF possui exatamente 11 dígitos
            if (cpfNumerico.length() != 11) {
                return false;
            }

            // Verificar se o CPF é composto apenas por dígitos repetidos
            if (cpfNumerico.matches("(\\d)\\1{10}")) {
                return false;
            }

            // Calcular os dígitos verificadores do CPF
            int[] digitos = new int[11];
            for (int i = 0; i < 11; i++) {
                digitos[i] = Integer.parseInt(cpfNumerico.substring(i, i + 1));
            }

            int soma = 0;
            for (int i = 0; i < 9; i++) {
                soma += digitos[i] * (10 - i);
            }

            int resto = soma % 11;
            int primeiroDigitoVerificador = (resto < 2) ? 0 : (11 - resto);

            if (digitos[9] != primeiroDigitoVerificador) {
                return false;
            }

            soma = 0;
            for (int i = 0; i < 10; i++) {
                soma += digitos[i] * (11 - i);
            }

            resto = soma % 11;
            int segundoDigitoVerificador = (resto < 2) ? 0 : (11 - resto);

            // Verificar se os dígitos verificadores do CPF são válidos
            return digitos[10] == segundoDigitoVerificador;
        }


        public static boolean validateCep (String cep){
            // Remover caracteres não numéricos
            String cepNumerico = cep.replaceAll("\\D", "");

            // Verificar se o CEP possui exatamente 8 dígitos
            if (cepNumerico.length() != 8) {
                return false;
            }

            // Verificar se o CEP é composto apenas por dígitos repetidos
            if (cepNumerico.matches("(\\d)\\1{7}")) {
                return false;
            }

            // Validar o CEP de acordo com regras específicas (se necessário)

            // Retornar true se o CEP for válido
            return true;
        }
    }

