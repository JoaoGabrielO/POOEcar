
INSERT INTO estacionamento(id, nome, cep, vagas) VALUES (1, 'Maria0', '0686765', '20');
INSERT INTO estacionamento(id, nome, cep, vagas) VALUES (2, 'Bob', '12345678', '29');
INSERT INTO estacionamento(id, nome, cep, vagas) VALUES (3, 'Alex', '87654321', '12');
INSERT INTO estacionamento(id, nome, cep, vagas) VALUES (4, 'Ana', '31526780', '0');