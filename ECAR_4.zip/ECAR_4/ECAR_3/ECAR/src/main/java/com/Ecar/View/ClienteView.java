package com.Ecar.View;

import com.Ecar.Controllers.ClienteController;
import com.Ecar.Entities.ClienteDAO;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



public class ClienteView {



  }

