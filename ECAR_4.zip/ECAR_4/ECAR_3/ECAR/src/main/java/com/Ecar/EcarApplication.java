package com.Ecar;


import com.Ecar.Controllers.ClienteController;
import com.Ecar.Entities.ClienteDAO;
import com.Ecar.Repositories.ClienteRepository;
import com.Ecar.View.ClienteView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;


@SpringBootApplication
public class
EcarApplication {
	@Bean
	public CommandLineRunner init(@Autowired ClienteRepository clienteRepository, @Autowired ClienteController clienteController) {

		return args -> {
			ClienteDAO c1 = new ClienteDAO(1,"daniel", "12345678", "12345678912");
			clienteController.insert(c1);
		};

	}

	public static void main(String[] args) {
		SpringApplication.run(EcarApplication.class, args);
		{

		}
	}
}

