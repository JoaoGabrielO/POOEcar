package com.Ecar.Entities;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "cliente")
public class ClienteDAO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private long id;
    private String nome, cep, cpf;

    @ManyToOne
    @JoinColumn(name = "estacionamento")
    private ClienteDAO estacionamento;

    public ClienteDAO(){}
    public ClienteDAO(long id, String nome, String cep, String cpf){
        this.id=id;
        this.nome=nome;
        this.cep=cep;
        this.cpf=cpf;


    }

    public ClienteDAO getEstacionamento() {
        return estacionamento;
    }

    public void setEstacionamento(ClienteDAO estacionamento) {
        this.estacionamento = estacionamento;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClienteDAO that = (ClienteDAO) o;
        return id == that.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
