
INSERT INTO estacionamento(id, cep, nome, vagas) VALUES (1, '06867650', 'Maria', '20');
INSERT INTO estacionamento(id, cep, nome, vagas) VALUES (2, '12345678', 'Bob', '29');
INSERT INTO estacionamento(id, cep, nome, vagas) VALUES (3, '87654321', 'Alex', '12');
INSERT INTO estacionamento(id, cep, nome, vagas) VALUES (4, '31526780', 'Ana', '0');