
INSERT INTO estacionamento(nome, cep, vagas) VALUES ('Maria0', '0686765', '20');
INSERT INTO estacionamento(nome, cep, vagas) VALUES ('Bob', '12345678', '29');
INSERT INTO estacionamento(nome, cep, vagas) VALUES ('Alex', '87654321', '12');
INSERT INTO estacionamento(nome, cep, vagas) VALUES ('Ana', '31526780', '0');