package com.Ecar.Repositories;

import com.Ecar.Entities.EstacionamentoDAO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface EstacionamentoRepository extends JpaRepository<EstacionamentoDAO, Long> {
}
