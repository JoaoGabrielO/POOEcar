package com.Ecar.Repositories;

import com.Ecar.Entities.ClienteDAO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ClienteRepository extends JpaRepository<ClienteDAO, Long> {

}
