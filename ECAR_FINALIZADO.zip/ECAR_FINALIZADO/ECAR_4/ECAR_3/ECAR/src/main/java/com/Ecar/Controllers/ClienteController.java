package com.Ecar.Controllers;


import java.util.Optional;
import com.Ecar.Entities.ClienteDAO;
import com.Ecar.Repositories.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping(value = "/clientes")
public class ClienteController {

    @Autowired
    private ClienteRepository repository;

    public ClienteController(ClienteRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public ResponseEntity<Object> findAll() {

        return ResponseEntity.status(HttpStatus.OK).body(repository.findAll());
    }

    @PostMapping(value = "")
    public ResponseEntity<Object> insert(@RequestBody ClienteDAO clienteDAO) {
        if (!validarCEP(clienteDAO.getCep())) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("O CEP invalido ou faltando caracteres!");
        }
        if (!validarCPF(clienteDAO.getCpf())) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("CPF invalido ou faltando caracteres!");
        }
        ClienteDAO result = repository.save(clienteDAO);
        return ResponseEntity.status(HttpStatus.CREATED).body("Cliente criado com sucesso.");
    }
    @GetMapping(value = "/{id}")
    public ResponseEntity<Object> findById(@PathVariable long id) {
        Optional<ClienteDAO> clienteDAOOptional = repository.findById(id);

        if (!clienteDAOOptional.isPresent()) {
            ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cliente não encontrado.");
        }
        return ResponseEntity.status(HttpStatus.OK).body(clienteDAOOptional.get());
    }
    @PutMapping("/{id}")
    public ResponseEntity<ClienteDAO> atualizarProduto(
            @PathVariable Long id,
            @RequestBody ClienteDAO produtoAtualizado) {
        Optional<ClienteDAO> produtoOptional = repository.findById(id);
        if (produtoOptional.isPresent()) {
            ClienteDAO clienteDAO = produtoOptional.get();
            clienteDAO.setNome(produtoAtualizado.getNome());
            clienteDAO.setCep(produtoAtualizado.getCep());
            clienteDAO.setCpf(produtoAtualizado.getCpf());

            if (validarCEP(clienteDAO.getCep())) {
                ResponseEntity.status(HttpStatus.CONFLICT).body("O CPF invalido ou faltando caracteres!");
            }
                if (validarCPF(clienteDAO.getCpf())) {
                    ResponseEntity.status(HttpStatus.CONFLICT).body("O CEP invalido ou faltando caracteres!");

                }

            repository.save(clienteDAO);
            return ResponseEntity.ok(clienteDAO);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
        @DeleteMapping(value = "/{id}")
        public ResponseEntity<Object> remover ( @PathVariable long id){
            Optional<ClienteDAO> clienteDAOOptional = repository.findById(id);

            if (clienteDAOOptional.isPresent()) {
                ClienteDAO clienteDAO = clienteDAOOptional.get();
                repository.delete(clienteDAO);
                return ResponseEntity.ok("Cliente removido com sucesso.");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cliente não encontrado");
            }
        }

    private static boolean validarCPF(String cpf) {
        cpf = cpf.replaceAll("[^\\d]", ""); // Remover caracteres não numéricos
        if (cpf.length() != 11 || cpf.matches("^(\\d)\1$")) {
            return false; // CPF com tamanho incorreto ou todos os dígitos iguais
        }

        int[] dig = new int[11];
        for (int i = 0; i < 11; i++) {
            dig[i] = Character.getNumericValue(cpf.charAt(i));
        }

        // Verificar o primeiro dígito verificador
        int soma = 0;
        for (int i = 0; i < 9; i++) {
            soma += dig[i] * (10 - i);
        }
        int resto = soma % 11;
        int digVerifica1 = resto < 2 ? 0 : 11 - resto;
        if (dig[9] != digVerifica1) {
            return false;
        }

        // Verificar o segundo dígito verificador
        soma = 0;
        for (int i = 0; i < 10; i++) {
            soma += dig[i] * (11 - i);
        }
        resto = soma % 11;
        int digVerifica2 = resto < 2 ? 0 : 11 - resto;
        return dig[10] == digVerifica2;
    }

    public static boolean validarCEP(String cep) {
        cep = cep.replaceAll("[^\\d]", ""); // Remover caracteres não numéricos
        return cep.matches("\\d{8}"); // Verificar se o CEP possui exatamente 8 dígitos numéricos
    }
    }

