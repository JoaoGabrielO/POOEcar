package com.Ecar.Controllers;

import com.Ecar.Entities.EstacionamentoDAO;
import com.Ecar.Repositories.EstacionamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;

@RestController
@RequestMapping(value = "/estacionamentos")
public class EstacionamentoController {

    @Autowired
    private EstacionamentoRepository repository;

    @GetMapping
    public ResponseEntity<Object> findAll() {

        return ResponseEntity.status(HttpStatus.OK).body(repository.findAll());
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<Object> findById(@PathVariable long id) {
        Optional<EstacionamentoDAO> estacionamentoDAOOptional = repository.findById(id);

        if (!estacionamentoDAOOptional.isPresent()) {
            ResponseEntity.status(HttpStatus.NOT_FOUND).body("Estacionamento não encontrado.");
        }
        return ResponseEntity.status(HttpStatus.OK).body(estacionamentoDAOOptional.get());
    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Object> remover ( @PathVariable long id){
        Optional<EstacionamentoDAO> estacionamentoDAOOptional = repository.findById(id);

        if (estacionamentoDAOOptional.isPresent()) {
            EstacionamentoDAO estacionamentoDAO = estacionamentoDAOOptional.get();
            repository.delete(estacionamentoDAO);
            return ResponseEntity.ok("Estacionamento removido com sucesso.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Estacionamento não encontrado");
        }
    }
}

