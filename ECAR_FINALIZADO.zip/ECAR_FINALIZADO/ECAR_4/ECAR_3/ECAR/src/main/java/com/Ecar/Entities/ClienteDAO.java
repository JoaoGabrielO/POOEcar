package com.Ecar.Entities;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "cliente")
public class ClienteDAO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private long id;
    private String nome, cep, cpf;

    @ManyToOne
    @JoinColumn(name = "estacionamento")
    private EstacionamentoDAO estacionamento;

    public ClienteDAO(){}
    public ClienteDAO( String nome, String cep, String cpf, EstacionamentoDAO estacionamento){
        this.nome=nome;
        this.cep=cep;
        this.cpf=cpf;
        this.estacionamento = estacionamento;

    }

    public EstacionamentoDAO getEstacionamento() {
        return estacionamento;
    }

    public void setEstacionamento(EstacionamentoDAO estacionamento) {
        this.estacionamento = estacionamento;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClienteDAO that = (ClienteDAO) o;
        return id == that.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
