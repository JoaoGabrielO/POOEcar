package com.Ecar;

import com.Ecar.Entities.ClienteDAO;
import com.Ecar.Entities.EstacionamentoDAO;
import com.Ecar.Repositories.ClienteRepository;
import com.Ecar.Repositories.EstacionamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;



@SpringBootApplication
public class
EcarApplication {
	@Bean
	public CommandLineRunner init(@Autowired ClienteRepository clienteRepository, EstacionamentoRepository estacionamentoRepository) {

		return args -> {
			EstacionamentoDAO e1 = new EstacionamentoDAO("ECAR", "12345678", "12");
			estacionamentoRepository.save(e1);
			ClienteDAO c1 = new ClienteDAO("Daniel", "12345678", "12345678912", e1);
			clienteRepository.save(c1);
		};

	}

	public static void main(String[] args) {
		SpringApplication.run(EcarApplication.class, args);
		{

		}
	}
}

