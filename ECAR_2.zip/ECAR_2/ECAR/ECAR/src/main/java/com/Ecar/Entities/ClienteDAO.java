package com.Ecar.Entities;

import jakarta.persistence.*;

@Entity
@Table(name = "cliente")
public class ClienteDAO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String nome, cep, cpf;

    @ManyToOne
    @JoinColumn(name = "estacionamento")
    private ClienteDAO estacionamento;
    public ClienteDAO(){

    }

    public ClienteDAO getEstacionamento() {
        return estacionamento;
    }

    public void setEstacionamento(ClienteDAO estacionamento) {
        this.estacionamento = estacionamento;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
}
