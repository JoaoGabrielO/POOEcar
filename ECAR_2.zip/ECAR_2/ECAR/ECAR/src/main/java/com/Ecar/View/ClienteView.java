package com.Ecar.View;

import com.Ecar.Controllers.ClienteController;
import com.Ecar.Entities.ClienteDAO;
import javax.swing.*;

public class ClienteView {
    ClienteController clienteController;
  public void registroCliente() {
      ClienteDAO clienteDAO = new ClienteDAO();
      JOptionPane.showMessageDialog(null, "Informações do Cliente:");
      clienteDAO.setId(1);
      clienteDAO.setNome(JOptionPane.showInputDialog("Nome: "));
      clienteDAO.setCep(JOptionPane.showInputDialog("CEP: "));
      clienteDAO.setCpf(JOptionPane.showInputDialog("CPF: "));
      clienteController.insert(clienteDAO);
  }

}
