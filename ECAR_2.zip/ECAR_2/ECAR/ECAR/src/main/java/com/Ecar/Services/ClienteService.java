package com.Ecar.Services;

import com.Ecar.Entities.ClienteDAO;
import com.Ecar.Repositories.ClienteRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClienteService {

    @Autowired
    ClienteRepository clienteRepository;

    @Transactional
    public ClienteDAO save(ClienteDAO clienteDAO){
        return clienteRepository.save(clienteDAO);
    }
    public Optional<ClienteDAO> findByid(long id){
        return clienteRepository.findById(id);
    }
    public List<ClienteDAO> findAll(){
        return clienteRepository.findAll();
    }

    @Transactional
    public void delete(ClienteDAO clienteDAO){
        clienteRepository.delete(clienteDAO);
    }
}
