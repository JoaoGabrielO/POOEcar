package com.Ecar.Controllers;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;

import com.Ecar.Entities.ClienteDAO;
import com.Ecar.Repositories.ClienteRepository;
import com.Ecar.Services.ClienteService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/cliente")
public class ClienteController {

    @Autowired
    private ClienteRepository clienteRepository;
    @Autowired
    ClienteService clienteService;

    @GetMapping
    public ResponseEntity<Object> retornaTudo(){

        return ResponseEntity.status(HttpStatus.OK).body(clienteService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Object> retornaPorId(@PathVariable long id){
        Optional<ClienteDAO> clienteDAOOptional = clienteService.findByid(id);

        if(!clienteDAOOptional.isPresent()){
            ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cliente não encontrado.");
        }
        return ResponseEntity.status(HttpStatus.OK).body(clienteDAOOptional.get());    }

    @PostMapping
    public ResponseEntity<Object> insert(@RequestBody ClienteDAO clienteDAO){

        if(clienteRepository.getCpf()){ // Verificando se o cpf ja esta cadastrado
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Conflito: CPF já cadastrado!");
        }
        if(!clienteRepository.getCep()){
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Conflito: CEP incorreto ou inexistente!");
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(clienteService.save(clienteDAO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity removerPorId(@PathVariable long id) {

        clienteRepository.deleteById(id);

        return  ResponseEntity.status(HttpStatus.OK).body("Informação deletada com sucesso!");
    }
    @PutMapping("/{id}")
    public  ResponseEntity atualiza(@PathVariable Long id, @RequestBody ClienteDAO user) {

        return  ResponseEntity.ok("Exemplo atualizado com sucesso!");
    }
}

