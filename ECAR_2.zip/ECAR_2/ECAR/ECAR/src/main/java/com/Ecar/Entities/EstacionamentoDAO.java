package com.Ecar.Entities;

import jakarta.persistence.*;

@Entity
@Table(name = "estacionamento")
public class EstacionamentoDAO {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String nome;
    private String cep, vagas;

    public EstacionamentoDAO(){

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String name) {
        this.nome = nome;
    }

    public String getCep() {
        return cep;
    }

    public String getVagas() {
        return vagas;
    }

    public void setVagas(String vagas) {
        this.vagas = vagas;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

}
