INSERT INTO cliente(nome, cep, cpf) VALUES ('mauro', '06867650', '145.226.154-90');
INSERT INTO cliente(nome, cep, cpf) VALUES ('arthur', '12345678', '45.366.544-94');

INSERT INTO estacionamento(id, cep, nome, vagas) VALUES (1, '06867650', 'Maria', '20');
INSERT INTO estacionamento(id, cep, nome, vagas) VALUES (2, '12345678', 'Bob', '29');
INSERT INTO estacionamento(id, cep, nome, vagas) VALUES (3, '87654321', 'Alex', '12');
INSERT INTO estacionamento(id, cep, nome, vagas) VALUES (4, '31526780', 'Ana', '0');